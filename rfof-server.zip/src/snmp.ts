import * as snmp from 'net-snmp';
import { SnmpVarBind, SnmpTableColumn, SnmpTable } from 'rfof-common';
import { execSync } from 'child_process';


export class SNMP {
	private community;
	private server;
	session;
	errorLog: string[] = [];
	constructor() {
		this.community = 'cMtc-04_3159';
		let options = {
			port: 161,
			version: snmp.Version2c
		};
		this.server = process.env.RFOF_CAGE_ADDRESS || 'localhost';
	}

	get(varBinds: SnmpVarBind[]) {
		let results = [];
		for (let varBind of varBinds) {
			let command = `snmpget -c ${this.community} -v 2c ${this.server} ${varBind.oid}`;
			if (varBind.index) {
				command += `.${varBind.index}`;
			}
			// console.log(command);
			let result = execSync(command).toString('utf-8');
			// console.log(result);
			let stringRegex = /^RFoF-Cage-MIB::(\w*)\s*=\s*STRING:\s*"([\w\s]*)"/;
			let integerRegex = /^RFoF-Cage-MIB::(\w*)\s*=\s*INTEGER:\s*(\d*)/;
			let integerRegexIdx = /^RFoF-Cage-MIB::(\w*)\s*[.\d]*\s*=\s*INTEGER:\s*\w*\((\d*)\)/;
			let stringRegexIdx = /^^RFoF-Cage-MIB::(\w*)\s*[.\d]*\s*=\s*STRING: "([\s\d\w\W]*)"/;
			let regexSatements = [stringRegex, integerRegex, integerRegexIdx, stringRegexIdx];

			varBind.value = null;
			for (let regex of regexSatements) {
				let matches = result.match(regex);
				if (matches) {
					varBind.value = matches[2].trim();
					break;
				}
			}
			results.push(varBind);
		}
		return results;
	}

	table(schema: SnmpTable) {
		let table = [];
		let command = `snmptable -v 2c -c ${this.community} -Ci -Os ${this.server} RFoF-Cage-MIB::${schema.systemName}`;
		let result = execSync(command).toString('utf-8');
		let lines = result.split(/\r?\n/);
		for (let line of lines) {
			let matches = line.match(new RegExp(schema.regex, 'i'));
			if (matches) {
				let row = {
					index: null,
					items: []
				};
				for (let varbind of schema.columns) {
					varbind.value = matches[varbind.tableIndex + 1].trim();
					row.items.push({... varbind});
				}
				row.index = matches[1].trim();
				table.push(row);
			}
		}
		return table;
	}

	set(varBinds: SnmpVarBind[]) {
		let results = [];
		for (let varBind of varBinds) {
			let command = `snmpset -Os -v2c -c ${this.community} ${this.server} RFoF-Cage-MIB::${varBind.systemName}.${varBind.index} ${varBind.type} ${varBind.value}`;
			// console.log(command);
			let result = execSync(command);
			results.push(result);
		}
		return results;
	}

	private buildSetCommand(command, data) {
		return command.replace(/\{\{(.*?)\}\}/g, (i, match) => {
			return data[match];
		});
	}

	close() {
		this.session.close();
	}
}

