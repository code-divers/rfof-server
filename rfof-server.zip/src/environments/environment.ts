
export const environment = {
	production: false,
	mock: false
};
