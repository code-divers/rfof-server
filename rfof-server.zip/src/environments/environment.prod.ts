
export const environment = {
	production: true,
	mock: false
};
