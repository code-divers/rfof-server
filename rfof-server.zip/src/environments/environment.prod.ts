export const environment = {
	production: true,
	mock: false,
	snmpConfig: '/etc/RFoptic/CageManager.conf',
	snmpDisableLog: true
};
