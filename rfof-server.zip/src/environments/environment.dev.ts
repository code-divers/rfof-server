export const environment = {
	production: false,
	mock: false,
	snmpConfig: '/Users/ytuvia/dev/rfof-server/CageManager.conf',
	snmpDisableLog: true
};
