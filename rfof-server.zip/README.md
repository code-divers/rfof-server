# rfof-server

A REST server that communicates with RFOptic cage.

## How to use it

1. Clone from github
2. Install npm module
3. Build project
4. Start the server

```
git clone git@github.com:code-divers/rfof-common.git
cd rfof-common
npm install
npm run build
npm start
```
